package cam.com.camex.adapters;

import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import cam.com.camex.R;
import cam.com.camex.fragments.MainItemFragment.OnListFragmentInteractionListener;
import cam.com.camex.pojos.CamItem;

import java.util.ArrayList;
import java.util.List;

/**
 * {@link RecyclerView.Adapter} that can display a {@link CamItem} and makes a call to the
 * specified {@link OnListFragmentInteractionListener}.
 *
 */
public class MyItemRecyclerViewAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {

    private  ArrayList<CamItem> mValues;
    private final OnListFragmentInteractionListener mListener;
    int level;

    public List<CamItem> getmValues() {
        return mValues;
    }

    public void setmValues(ArrayList<CamItem> camItems) {
        mValues=camItems;
    }

    public MyItemRecyclerViewAdapter(ArrayList<CamItem> items, OnListFragmentInteractionListener listener, int level_) {
        mValues = items;
        mListener = listener;
        level=level_;
    }

    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {

     if(level==1){
         View view = LayoutInflater.from(parent.getContext())
                 .inflate(R.layout.griditem_layout, parent, false);
         return new GridViewHolder(view);
     }
     else {
         View view = LayoutInflater.from(parent.getContext())
                 .inflate(R.layout.fragment_item, parent, false);
         return new ViewHolder(view);
     }


    }

    @Override
    public void onBindViewHolder(final RecyclerView.ViewHolder holder, final int position) {
      if(level==1){
          GridViewHolder gridViewHolder= (GridViewHolder) holder;
          gridViewHolder.mContentView.setText(mValues.get(position).getTitle());
          gridViewHolder.mView.setOnClickListener(new View.OnClickListener() {
              @Override
              public void onClick(View v) {
                  if (null != mListener) {
                      // Notify the active callbacks interface (the activity, if the
                      // fragment is attached to one) that an item has been selected.
                      mListener.onListFragmentInteraction(mValues.get(position),position);
                  }
              }
          });
      }
      else {
          final ViewHolder subViewHolder= (ViewHolder) holder;
          if(level==5){

              subViewHolder.mIdView.setText(mValues.get(position).getVal1());
              subViewHolder.mIdView.setTextColor(android.R.color.white);
          }
          else {
              subViewHolder.mItem = mValues.get(position);
              subViewHolder.mIdView.setText(mValues.get(position).getTitle());
              subViewHolder.mContentView.setText(mValues.get(position).getDescription());

              subViewHolder.mView.setOnClickListener(new View.OnClickListener() {
                  @Override
                  public void onClick(View v) {
                      if (null != mListener) {
                          // Notify the active callbacks interface (the activity, if the
                          // fragment is attached to one) that an item has been selected.
                          mListener.onListFragmentInteraction(subViewHolder.mItem,position);
                      }
                  }
              });
          }

      }

    }

    @Override
    public int getItemCount() {
        return mValues.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        public final View mView;
        public final TextView mIdView;
        public final TextView mContentView;
        public CamItem mItem;

        public ViewHolder(View view) {
            super(view);
            mView = view;
            mIdView = (TextView) view.findViewById(R.id.item_number);
            mContentView = (TextView) view.findViewById(R.id.content);
        }

        @Override
        public String toString() {
            return super.toString() + " '" + mContentView.getText() + "'";
        }
    }

    public class GridViewHolder extends RecyclerView.ViewHolder{
        public final TextView mContentView;
        public final View mView;
        public GridViewHolder(@NonNull View itemView) {
            super(itemView);
            mView=itemView;
            mContentView = (TextView) itemView.findViewById(R.id.txtName);
        }

    }
}
