package cam.com.camex.fragments;

import android.arch.lifecycle.ViewModelProviders;
import android.content.Context;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import cam.com.camex.R;
import cam.com.camex.adapters.ExpandableAdapter;
import cam.com.camex.adapters.MyItemRecyclerViewAdapter;
import cam.com.camex.pojos.CamItem;
import cam.com.camex.utilities.RecyclerViewDividerItemDecoration;
import cam.com.camex.viewmodles.ContentViewModel;

import java.util.ArrayList;

/**
 * A fragment representing a list of Items.
 * <p/>
 * Activities containing this fragment MUST implement the {@link OnListFragmentInteractionListener}
 * interface.
 */
public class MainItemFragment extends Fragment {

    // TODO: Customize parameter argument names
    private static final String ARG_COLUMN_COUNT = "column-count";
    private static final String ARG_COLUMN_LEVEL = "level";
    private static final String ARG_COLUMN_PARENT_POSITION = "parent_pos";
    private static final String ARG_COLUMN_CHILD_POSITION = "child_pos";
    // TODO: Customize parameters
    private int mColumnCount = 1;
    private int mLevel = 1;
    private int mParentPos = -1;
    private int mChildPos = -1;
    private OnListFragmentInteractionListener mListener;
    ArrayList<CamItem> camItemArrayList;
    ContentViewModel contentViewModel;

    /**
     * Mandatory empty constructor for the fragment manager to instantiate the
     * fragment (e.g. upon screen orientation changes).
     */
    public MainItemFragment() {
    }


    // TODO: Customize parameter initialization
    @SuppressWarnings("unused")
    public static MainItemFragment newInstance(int columnCount,int level,int parentPosition,int childPoistion ) {
        MainItemFragment fragment = new MainItemFragment();
        Bundle args = new Bundle();
        args.putInt(ARG_COLUMN_COUNT, columnCount);
        args.putInt(ARG_COLUMN_LEVEL, level);
        args.putInt(ARG_COLUMN_PARENT_POSITION, parentPosition);
        args.putInt(ARG_COLUMN_CHILD_POSITION, childPoistion);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        if (getArguments() != null) {
            mColumnCount = getArguments().getInt(ARG_COLUMN_COUNT,1);
            mLevel = getArguments().getInt(ARG_COLUMN_LEVEL,1);
            mParentPos = getArguments().getInt(ARG_COLUMN_PARENT_POSITION,-1);
            mChildPos = getArguments().getInt(ARG_COLUMN_CHILD_POSITION,-1);
        }
        contentViewModel= ViewModelProviders.of(getActivity()).get(ContentViewModel.class);

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_item_list, container, false);
        if(mLevel==1){
            camItemArrayList=contentViewModel.getCamItemArrayList();
        }
        else if(mLevel==2){
            camItemArrayList=contentViewModel.getCamItemArrayList().get(mParentPos).getSubitemList();
        }
        else if(mLevel==3){
            camItemArrayList=contentViewModel.getCamItemArrayList().get(mParentPos).getSubitemList().get(mChildPos).getSubitemList();
        }
        // Set the adapter
        if (view instanceof RecyclerView) {
            Context context = view.getContext();
            RecyclerView recyclerView = (RecyclerView) view;
            if (mColumnCount <= 1) {
                recyclerView.setLayoutManager(new LinearLayoutManager(context));
            } else {
                recyclerView.setLayoutManager(new GridLayoutManager(context, mColumnCount));
            }
            if(mLevel!=1){
                recyclerView.addItemDecoration(new RecyclerViewDividerItemDecoration(getActivity(), R.drawable.divider_doc_list));
            }
            if(mLevel==2 && mParentPos==6){
                recyclerView.setAdapter(new ExpandableAdapter(camItemArrayList));
            }
            else {
                recyclerView.setAdapter(new MyItemRecyclerViewAdapter(camItemArrayList, mListener,mLevel));
            }

        }
        return view;
    }


    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        if (context instanceof OnListFragmentInteractionListener) {
            mListener = (OnListFragmentInteractionListener) context;
        } else {
            throw new RuntimeException(context.toString()
                    + " must implement OnListFragmentInteractionListener");
        }
    }

    @Override
    public void onDetach() {
        super.onDetach();
        mListener = null;
    }

    /**
     * This interface must be implemented by activities that contain this
     * fragment to allow an interaction in this fragment to be communicated
     * to the activity and potentially other fragments contained in that
     * activity.
     * <p/>
     * See the Android Training lesson <a href=
     * "http://developer.android.com/training/basics/fragments/communicating.html"
     * >Communicating with Other Fragments</a> for more information.
     */
    public interface OnListFragmentInteractionListener {
        // TODO: Update argument type and name
        void onListFragmentInteraction(CamItem item,int pos);
    }
}
