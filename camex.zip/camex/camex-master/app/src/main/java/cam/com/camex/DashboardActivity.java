package cam.com.camex;

import android.arch.lifecycle.ViewModel;
import android.arch.lifecycle.ViewModelProviders;
import android.content.Context;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.FrameLayout;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;

import cam.com.camex.fragments.MainItemFragment;
import cam.com.camex.pojos.CamItem;
import cam.com.camex.pojos.CamItemListPojo;
import cam.com.camex.viewmodles.ContentViewModel;

public class DashboardActivity extends AppCompatActivity implements MainItemFragment.OnListFragmentInteractionListener {


    FrameLayout mainFrameLayout;
    ContentViewModel contentViewModel;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dashboard);
        mainFrameLayout=findViewById(R.id.main_container);
        String content=getContent();
        Gson gson = new GsonBuilder().create();
        CamItemListPojo camItemListPojo=gson.fromJson(content, CamItemListPojo.class);

        contentViewModel= ViewModelProviders.of(DashboardActivity.this).get(ContentViewModel.class);
        contentViewModel.setCamItemArrayList(camItemListPojo.getCamItemArrayList());

        replaceFragment(MainItemFragment.newInstance(2,1,-1,-1),"first level",false);




    }

    void replaceFragment(Fragment fragment,  String transactionName, Boolean addTobackstack) {
        FragmentManager fragmentManager=getSupportFragmentManager();
        FragmentTransaction fragmentTransaction =fragmentManager.beginTransaction();
        fragmentTransaction.replace(R.id.main_container,fragment,transactionName);
        if (addTobackstack) {
            fragmentTransaction.addToBackStack(transactionName);
        }
        fragmentTransaction.commit();
    }

    @Override
    public void onListFragmentInteraction(CamItem item,int pos) {
        if(item.getSubitemList()==null){
            return;
        }
        else {
            replaceFragment(MainItemFragment.newInstance(1,2,pos,-1),"2nd level",false);
        }
    }

    String getContent(){
        InputStream inputStream = getResources().openRawResource(R.raw.camcontent);

        ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();

        int i;
        try {
            i = inputStream.read();
            while (i != -1)
            {
                byteArrayOutputStream.write(i);
                i = inputStream.read();
            }
            inputStream.close();
        } catch (IOException e) {
            return null;
        }
        return byteArrayOutputStream.toString();
    }
}
