package cam.com.camex.adapters;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.List;

import cam.com.camex.R;
import cam.com.camex.pojos.CamItem;

public class ExpandableAdapter extends RecyclerView.Adapter<ExpandableAdapter.ExpandableViewHolder> {
    private final List<CamItem> mValues;
    Context mContext;

    public ExpandableAdapter(List<CamItem> mValues) {
        this.mValues = mValues;
    }

    @NonNull
    @Override
    public ExpandableAdapter.ExpandableViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {

        View view = LayoutInflater.from(viewGroup.getContext())
                .inflate(R.layout.layout_header_expand_recycler, viewGroup, false);
        ExpandableViewHolder expandableViewHolder= new ExpandableViewHolder(view);

        GridLayoutManager gridLayoutManager = new GridLayoutManager(viewGroup.getContext(), 1);
        expandableViewHolder.childExpandableRecyclerView.setLayoutManager(gridLayoutManager);
        return expandableViewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull ExpandableAdapter.ExpandableViewHolder viewHolder, int pos) {

        viewHolder.headerTextView.setText(mValues.get(pos).getTitle());
        if(viewHolder.expandableChildRecyclerViewAdapter==null){
            viewHolder.expandableChildRecyclerViewAdapter=new MyItemRecyclerViewAdapter(mValues.get(pos).getSubitemList(),null,5);
             viewHolder.childExpandableRecyclerView.setAdapter(viewHolder.expandableChildRecyclerViewAdapter);
        }
        else{
            viewHolder.expandableChildRecyclerViewAdapter.setmValues(mValues.get(pos).getSubitemList());
            viewHolder.expandableChildRecyclerViewAdapter.notifyDataSetChanged();
        }

    }

    @Override
    public int getItemCount() {
        return mValues.size();
    }

    class ExpandableViewHolder extends RecyclerView.ViewHolder {
        View parentView;
        public final TextView headerTextView;
        public final RecyclerView childExpandableRecyclerView;

        public MyItemRecyclerViewAdapter expandableChildRecyclerViewAdapter;

        public MyItemRecyclerViewAdapter getExpandableChildRecyclerViewAdapter() {
            return expandableChildRecyclerViewAdapter;
        }

        public void setExpandableChildRecyclerViewAdapter(MyItemRecyclerViewAdapter expandableChildRecyclerViewAdapter) {
            this.expandableChildRecyclerViewAdapter = expandableChildRecyclerViewAdapter;
        }

        public ExpandableViewHolder(View itemView) {
            super(itemView);
            parentView = itemView;
            childExpandableRecyclerView = itemView.findViewById(R.id.child_expandable_recyclerview);
            headerTextView = itemView.findViewById(R.id.expand_header);


        }
    }
}
