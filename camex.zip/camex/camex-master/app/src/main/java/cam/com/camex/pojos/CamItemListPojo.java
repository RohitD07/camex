package cam.com.camex.pojos;

import com.google.gson.annotations.SerializedName;

import java.util.ArrayList;

public class CamItemListPojo {
    @SerializedName("datalist")
    ArrayList<CamItem> camItemArrayList;

    public ArrayList<CamItem> getCamItemArrayList() {
        return camItemArrayList;
    }

    public void setCamItemArrayList(ArrayList<CamItem> camItemArrayList) {
        this.camItemArrayList = camItemArrayList;
    }
}
