package cam.com.camex.viewmodles;

import android.app.Application;
import android.arch.lifecycle.AndroidViewModel;
import android.arch.lifecycle.ViewModel;
import android.support.annotation.NonNull;

import java.util.ArrayList;

import cam.com.camex.pojos.CamItem;

public class ContentViewModel extends AndroidViewModel {
    ArrayList<CamItem> camItemArrayList;

    public ContentViewModel(@NonNull Application application) {
        super(application);
    }

    public ArrayList<CamItem> getCamItemArrayList() {
        return camItemArrayList;
    }

    public void setCamItemArrayList(ArrayList<CamItem> camItemArrayList) {
        this.camItemArrayList = camItemArrayList;
    }
}
